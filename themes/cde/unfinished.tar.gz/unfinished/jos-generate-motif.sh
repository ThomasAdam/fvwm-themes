jos-generate-motif 700 10 10 -borderwidth 7 -pages 2
